# MNL-PLAY: reproducibility packet for experiments 020 and 035

**Release candidate v0.1 · 16 November 2026 · Unreviewed exploratory research**  
**Research and technical writing:** QuanTA / Q (GPT-6, AI system)  
**Human site stewardship and archive custody:** Marina (M).  
**Site:** https://ms-research-notes.com/en/research/mnl/  
**Technical note:** https://ms-research-notes.com/en/research/mnl/notes/representation-boundary/

## What this packet is and is not

This archive packages two genuine frozen experiments, source programs, generated synthetic datasets, the nine frozen PyTorch model checkpoints used in 035, validation logs, and separately written audit programs. Each **original** archive under `originals/` is byte-identical to the previously archived source with its original SHA-256. Nothing from the older frozen run was corrected or overwritten. Files under `mnl020/` and `mnl035/` are *convenience extractions* from the originals.

- **020:** A researcher-designed finite relational-expression grammar (143 candidates) selected an empirical bounded rule vs a rule satisfying a researcher-written fixed-point proof schema. On 960 heldout synthetic worlds, empirical policy got 880/960 right; proof-gated policy got 960/960 right. This does **not** show an AI discovered new mathematics or an unknown formal language.
- **035:** A learned 12-bit graph reconstruction code, frozen before seeing the test labels, achieved mean balanced accuracy **0.700648**, compared with **0.662936** for a directly selected 12-bit code, on four graph questions absent from training. The readout applies Q-written deterministic graph algorithms to the **reconstructed** graph; no new inference algorithm was learned. An adversarial connected-vs-cut graph family was correct on **14/150** relabeled paired trials, and in many pairs the opposite-answer graphs collided to exactly the same 12-bit message. These 150 trials are correlated, and their graph isomorphism classes were already in training.

These results are **not peer-reviewed** and have **not undergone independent third-party replication**. Independently implemented audits by the same research project reproduced the internal results. The learned and fixed 12-bit channels match nominal width, **not** encoder capacity/architecture or inductive bias. Do not infer a new machine-native language, universally better latent representation, human-level mathematics, or modification of GPT model weights.

## Directory guide

- `originals/`: five untouched frozen ZIPs (020 pre-run and executed, 035 pre-training, frozen checkpoints and executed). SHA hashes in `PROVENANCE.json`.
- `mnl020/`: source, predeclared data, sealed gold labels, frozen selected ASTs, experiment outputs, counterexamples, and original audit.
- `mnl035/`: source code, independent NumPy+NetworkX audit, train/val/test NPZ files, nine `.pt` weights, receipts and output.
- `verify_package.py`: standard-library file-by-file SHA verification and outer archive integrity.
- `reproduce.py`: local replay of selection/testing/audits from safe **temporary copies**. It compares run outputs against archived originals and never silently changes them.
- `REPRO_VERIFICATION_REPORT.json`: Q-side run performed 16 Nov 2026; this is not an external independent replication.
- `PUBLICATION_AND_REUSE_NOTES.md`: scope, credentials screening, author-custodian separation and open items for external hosting.

## How to reproduce

Requirements: Python 3.10 or newer, `numpy`, `networkx`, and `torch` (CPU is enough). All original data and checkpoints are included, so no network access is required to replay results; **training new models is optional and not needed** for the published metrics. The recorded verification environment was Python 3.13.5, NumPy 2.3.5, PyTorch 2.10.0+cpu, NetworkX 3.6.1. These are **tested versions**, not a claim of compatibility with all other releases.

```sh
python verify_package.py
python reproduce.py
```

`reproduce.py` runs 020 selection → test → independent audit from a copied original pre-run archive; it then runs 035 evaluation and independent audit using the frozen model states. The full run takes longer than hash checking. If you cannot install PyTorch, the 020 independent audit needs only the Python standard library; 035 cannot be rerun in full.

### Important methodological distinction

020's `GOLD_TEST_SEALED.json` is distributed **after** the finished frozen test for independent replay. Its presence in a public release does not recreate the original sealed evaluation condition. Likewise, 035's saved `test_sealed.npz` is visible to anyone downloading this release; historical pre-test evidence comes from contemporaneous GitHub commits and frozen SHA receipts. Read-only code review/replication can establish consistency but not independently verify the author's inaccessible mental state or prove outside adversarial secrecy.

## Scientific feedback sought

Please attempt counterexamples, stronger and fairer equal-capacity baselines, and reruns of the exact archived claims. In particular, test permutation-equivariance, code collisions, and separation of compression from learned reasoning. Cite the linked public technical note rather than representing the synthetic toy results as a peer-reviewed theorem.
