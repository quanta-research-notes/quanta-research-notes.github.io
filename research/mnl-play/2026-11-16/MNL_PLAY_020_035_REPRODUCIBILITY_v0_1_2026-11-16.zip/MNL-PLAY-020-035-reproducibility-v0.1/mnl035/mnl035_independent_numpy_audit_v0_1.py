#!/usr/bin/env python3
"""Independent, post-result audit: no imports from mnl035_zeroprobe.py.
Loads frozen checkpoints with torch only for serialization; inference and graph ground truth
are separately implemented in NumPy + NetworkX, with source/data integrity controls.
"""
from pathlib import Path
from itertools import permutations, combinations
import hashlib,json,zipfile,sys
import numpy as np
import networkx as nx
import torch

R=Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/MNL_PLAY_035')
EDGES=tuple((u,v) for u in range(5) for v in range(5) if u!=v)
I={e:i for i,e in enumerate(EDGES)}
FAMILIES=('twohop','reach','mutual','triangle')

def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_npz(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}

def canon_alt(x):
 arr=np.zeros((5,5),np.uint8)
 for k,(u,v) in enumerate(EDGES):arr[u,v]=int(x[k])
 candidates=[]
 for perm in permutations(range(5)):
  # perm old index -> new index, no reuse of original bit-transform routine
  y=np.zeros((5,5),np.uint8)
  for u in range(5):
   for v in range(5):
    if arr[u,v]:y[perm[u],perm[v]]=1
  z=0
  for i,e in enumerate(EDGES): z += int(y[e])*2**i
  candidates.append(z)
 return min(candidates)

def ground_truth(row):
 g=nx.DiGraph();g.add_nodes_from(range(5))
 g.add_edges_from((u,v) for k,(u,v) in enumerate(EDGES) if row[k])
 d={u:nx.descendants(g,u) for u in range(5)}
 t={u:[w for v in g.successors(u) for w in g.successors(v)] for u in range(5)}
 v={"twohop":[],"reach":[],"mutual":[],"triangle":[]}
 for u,w in EDGES:
  v['twohop'].append(int(w in t[u]));v['reach'].append(int(w in d[u]));v['mutual'].append(int(w in d[u] and u in d[w]))
 v['triangle'].append(int(any((g.has_edge(u,v) and g.has_edge(v,w) and g.has_edge(w,u)) for u,v,w in permutations(range(5),3))))
 return v

def all_truth(X):
 cache={};r={f:[] for f in FAMILIES}
 for x in X:
  key=bytes(x.tolist())
  if key not in cache:cache[key]=ground_truth(x)
  for f in FAMILIES:r[f].extend(cache[key][f])
 return {k:np.array(v,dtype=np.uint8) for k,v in r.items()}

def bac(y,p):
 y=np.asarray(y);p=np.asarray(p)
 if not (np.any(y==0) and np.any(y==1)):return None
 return float(((p[y==0]==0).mean()+(p[y==1]==1).mean())/2)

def numpy_reconstruct(kind,seed,X):
 weights=torch.load(R/'checkpoints'/f'{kind}_s{seed}.pt',map_location='cpu',weights_only=True)
 w={k:v.detach().numpy() for k,v in weights.items()}
 def net(prefix,x):
  a=np.maximum(0,x@w[prefix+'.0.weight'].T+w[prefix+'.0.bias'])
  b=a@w[prefix+'.2.weight'].T+w[prefix+'.2.bias']
  return b
 X=np.asarray(X,np.float32)
 if kind=='learned12':
  code=(net('enc',X)>=0).astype(np.float32)
 elif kind=='direct12': code=X[:,:12]
 elif kind=='parity12':code=np.remainder(X@w['fixed'].T,2)
 else:raise ValueError(kind)
 logits=net('dec',code)
 return code.astype(np.uint8),(logits>=0).astype(np.uint8)

freeze=json.loads((R/'MNL035_PRETRAINING_FREEZE_RECEIPT_v0_1.json').read_text())
prezip=R/'MNL035_PRERUN_FROZEN_v0_1.zip'
pre_ok=h(prezip)==freeze['archive_sha256']
errors=[]
with zipfile.ZipFile(prezip) as z:
 for name,desc in freeze['members'].items():
  b=z.read(name)
  if hashlib.sha256(b).hexdigest()!=desc['sha256']:errors.append('freeze-member:'+name)

ck=json.loads((R/'MNL035_CHECKPOINT_FREEZE_RECEIPT_v0_1.json').read_text())
check_zip=R/'MNL035_CHECKPOINTS_BEFORE_TEST_v0_1.zip'
ck_ok=h(check_zip)==ck['sha256']
with zipfile.ZipFile(check_zip) as z:
 for kind in ('learned12','direct12','parity12'):
  for seed in (3001,3002,3003):
   n=f'{kind}_s{seed}.pt'
   expect=ck['checkpoint_shas'][f'{kind}_{seed}']
   if hashlib.sha256(z.read('checkpoints/'+n)).hexdigest()!=expect:errors.append('checkpoint-zip:'+n)
   if h(R/'checkpoints'/n)!=expect:errors.append('checkpoint-local:'+n)

splits={s:load_npz(R/f'{s}.npz') for s in ('train','val','test_sealed')}
keys=[];view_mismatches={};
for name,z in splits.items():
 own=set();err=0
 for j,x in enumerate(z['x']):
  group=int(z['group'][j]); calc=canon_alt(x)
  if int(z['canonical'][group]) != calc:err+=1
  own.add(calc)
 view_mismatches[name]=err;keys.append(own)
split_disjoint=all(len(keys[a]&keys[b])==0 for a,b in combinations(range(3),2))
results=json.loads((R/'eval_result.json').read_text())
X=splits['test_sealed']['x'];T=all_truth(X)
trues={f:int(np.sum(T[f])) for f in FAMILIES}
compare={};mismatch_score=[]
for row in results['per_run']:
 k=row['kind'];seed=row['seed'];code,pred=numpy_reconstruct(k,seed,X)
 got=all_truth(pred)
 scores={f:bac(T[f],got[f]) for f in FAMILIES}
 scores['macro']=float(np.mean(list(scores.values())))
 scores['edge_reconstruction_accuracy']=float(np.mean(X==pred))
 for metric,sc in scores.items():
  if sc is None or not np.isclose(sc,row['metrics'][metric],atol=1e-9):mismatch_score.append(f'{k}_{seed}_{metric}:{sc}/{row["metrics"].get(metric)}')
 compare[f'{k}_{seed}']={'macro':scores['macro'],'message_uniques':len(np.unique(code,axis=0))}
 if len(np.unique(code,axis=0))!=row['encoded_unique_messages']:errors.append('unique-messages:'+k+str(seed))

# Match archived overall groups and transfer threshold.
means={}
for kind in ('learned12','direct12','parity12'):
 means[kind]=float(np.mean([compare[f'{kind}_{seed}']['macro'] for seed in (3001,3002,3003)]))
 if not np.isclose(means[kind],results['summary'][kind]['macro'],atol=1e-9):errors.append('macro-mismatch:'+kind)

receipt={
 'study':'MNL-PLAY-035','audit':'second auditor independent source/NumPy forward/NetworkX truth',
 'prefreeze_archive_sha_match':pre_ok,'prefreeze_member_errors':errors,
 'checkpoint_archive_sha_match':ck_ok,'independent_recanon_view_mismatches':view_mismatches,
 'isoclass_splits_disjoint':split_disjoint,'all_test_query_true_counts':trues,
 'independent_numpy_replay_mismatches':mismatch_score,'independently_recalculated_macros':means,
 'tests_are_relabelings_of_300_classes':True,
 'cannot_prove_human_independence_or_data_prior_exposure':True,
 'audit_pass':pre_ok and ck_ok and not errors and not mismatch_score and split_disjoint and all(v==0 for v in view_mismatches.values())
}
(R/'MNL035_INDEPENDENT_AUDIT_RESULT_v0_1.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
