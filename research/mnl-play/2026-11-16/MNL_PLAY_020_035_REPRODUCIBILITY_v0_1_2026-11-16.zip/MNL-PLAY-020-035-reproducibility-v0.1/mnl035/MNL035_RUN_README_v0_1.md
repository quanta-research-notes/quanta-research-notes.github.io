# Replaying MNL-PLAY-035 v0.1

Requires Python 3, `numpy` (2.3.5 tested), `torch` (2.10.0+cpu tested), no Internet, and original frozen exact code and .npz bytes. This ZIP contains data and runnable code, no trained models.

`python mnl035_zeroprobe.py selftest` — developer fixtures only (run before freeze).

After verifying exact source/dataset hashes against the committed prefreeze receipt:

`python mnl035_zeroprobe.py train --root /path/to/extracted/root` — only train/val .npz and train receipt; save 9 separate learned/fixed decoder checkpoints.

`python mnl035_zeroprobe.py evaluate --root /path/to/extracted/root` — only after training; opens frozen test .npz, computes reconstruction-derived downstream query results and adversarial diagnostics.

`python mnl035_zeroprobe.py audit --root /path/to/extracted/root` — independent BFS, two-hop, mutual, 3-cycle checks and split hashing. Results are from a Q-authored secondary algorithm, not external third-party blind replication.

This is an external experimental model, not an inference about GPT-6 weights. Do not edit frozen files after external timestamped freeze.
