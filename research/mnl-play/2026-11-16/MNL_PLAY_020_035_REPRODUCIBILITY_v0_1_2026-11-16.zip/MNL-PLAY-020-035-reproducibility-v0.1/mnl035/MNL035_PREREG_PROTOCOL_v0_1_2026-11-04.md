# MNL-PLAY-035 — Zero-probe learned-bit representation pilot, preregistration v0.1

Date: 2026-11-04 JST. **Scope: frozen prospective PILOT in a small externally implemented neural model.** Not GPT-6 weight learning; not a claim of novel mathematics, machine-native language, or IUT reading. Do not change any earlier MNL experiment freeze. 034 overall HOLD is not upgraded.

## Primary question and methodological gap
Prior 008 trained an *additional downstream probe on the new task*. Here **no labels or trainable parameters for any downstream test task** are used at training or adaptation time. Instead, a sender/receiver pair learns to reconstruct raw graph edges through a finite binary message. After the learned code and decoder are frozen, fixed, human-written algorithms evaluate **unseen task families** on the reconstructed graph. This isolates *zero-new-task-training transfer via an approximate reconstructed structure*, not autonomous invention of task semantics or a proof.

## Input, data, split and independence
- Raw input: 5-node simple loopless **directed** adjacency graph (20 binary edge variables), label values 0/1.
- Graphs sampled by deterministic RNG seed `350204` from a mixture of independent Bernoulli-edge distributions at p ∈ {0.26, 0.35, 0.45}.
- Isomorphism canonicalization enumerates all 5! vertex relabelings, then deduplicates **whole graph isomorphism classes**, not merely graph bytes. Exactly **1,200 train classes, 300 validation classes, 300 sealed test classes**, no overlap; 4 node-label permutations per train class and 2 for validation/test: 4,800/600/600 graph views respectively.
- All test inputs and the evaluator algorithm exist in the frozen ZIP, but **training subprocess only reads `train.npz` and `val.npz`, never `test_sealed.npz` or labels computed from it**. This is a predeclared test split, not proof of an unexposed human or model evaluator. Instances sharing an isoclass remain correlated and are not independent samples.

## Matching capacity and model conditions
- Learned code: `learned12`: 20-bit adjacency → MLP(64 hidden) → **12 hard binary bits**, straight-through gradient, MLP(64 hidden) → 20 edge reconstruction logits.
- Same 12-bit channel, fixed-code baselines with trained decoder of same architecture:
  - `direct12`: the first twelve adjacency bits as an explicitly human-chosen simple code;
  - `parity12`: 12 fixed random XORs of three input edges, generated for each model seed before training.
- Seeds: `3001,3002,3003`. All train **only** on binary cross-entropy loss for edge reconstruction; validation reconstruction BCE selects checkpoints. Adam learning rate .003, batch128, max70 epochs, patience12, three fixed replicates/condition; no test-based tuning or head replacement.
- Equal nominal channel bits, but encoder parameter count and information structure differ. Baselines cannot establish a universal causal benefit of learned communication; particularly the parity baseline is a weak control against source reconstruction.
- Full raw 20-bit adjacency is a **different-capacity upper reference (exactly correct with deterministic query algorithms)**, not a peer baseline.

## Unseen-task readout (strictly no new-task labels for training)
Only after all checkpoints are frozen, evaluate decoder-thresholded adjacency using **fixed, hand-written** algorithms for:
1. `twohop`: a directed walk of exactly length 2 for each ordered unequal node pair;
2. `reach`: a directed walk of ≥1 edges for each ordered unequal pair;
3. `mutual`: both directed reachability directions hold for each ordered unequal pair;
4. `triangle`: any 3-distinct-vertex directed 3-cycle exists in the whole graph.

Correct labels are computed from the original graph independently. Main metric = **macro mean of per-task balanced accuracy (BA)** on the 600 test views, averaged over 3 fixed training seeds. Report every task, each seed, and a separate edge reconstruction accuracy. BA for any task lacking both classes => FAIL_METRIC, do not fill with zero or guess. The 600 views represent only 300 base isomorphism classes.

## Predeclared decisions and negative tests
- `TRANSFER_SIGNAL_PREDECLARED` iff the learned12 macro BA is ≥ .60, exceeds the **stronger of direct12 and parity12 mean macro BA by ≥ .03**, and is ≥ .10 above the learned-code **shuffled-message** macro BA.
- Otherwise `TRANSFER_SIGNAL_NOT_ESTABLISHED`; do not tune to the result. Even a positive result is an **exploratory signal**, not demonstration of new language, human-uninterpretable representation, discovered mathematical theorem, nonhuman cognitive state, or statistical significance.
- A separate 50-pair *constructed* connected/cut 5-node long-chain diagnostic checks if each code distinguishes reachability at the old endpoints. This counterexample family is repeated under relabeling, so treat 50 as correlated variations and do not pool into the primary 600 observations.
- Q-written post-run auditor recomputes directed reachability via BFS, `twohop`, mutual reachability and directed triangles independently; checks test/train/validation canonical disjointness, class uniqueness, 12-bit width and input data hashes. Failing source or audit checks => `AUDIT_HOLD` overriding any score.
- Any trial or correction after seeing test results gets a new version; do not retroactively claim preregistered success. Record errors, failed preflights and amended source hashes separately.

## Known limits / interpretation
- The learned code is *not* a self-discovered deductive calculus: a human-defined adjacency reconstruction loss, graph family, evaluation algorithms, neural architecture and 12-bit channel make this a controlled proof of concept.
- 'Zero-probe' refers only to absence of downstream **task-specific training**. It does NOT mean the downstream task evaluator is learned zero-shot; it is a fixed program written by Q.
- No new author/paper validation, no Lean kernel rerun, no speculative inference about IUT, and no claim that GPT-6 itself modifies its internal weights.
- Prior 007–034 retain their own statuses; the 034 source-to-Lean mapping H/O/L/D gates remain separate.
