#!/usr/bin/env python3
"""MNL-PLAY-035: preregisterable 5-node graph autoencoding / zero-new-task-training pilot.

Subcommands: selftest, prepare, train, evaluate, audit.
Source of authority: freeze protocol and SHA256 receipt; training code never loads TEST.
"""
import argparse
import csv
import hashlib
import itertools
import json
import math
import os
import random
from collections import deque, defaultdict
from pathlib import Path
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

torch.set_num_threads(1)
N = 5
EDGES = [(i, j) for i in range(N) for j in range(N) if i != j]
B = len(EDGES)
W = 12
EXP_SEEDS = (3001, 3002, 3003)
DATA_SEED = 350204
P_GRID = (0.26, 0.35, 0.45)
N_TRAIN, N_VAL, N_TEST = 1200, 300, 300
AUG_TRAIN, AUG_VAL, AUG_TEST = 4, 2, 2
EPOCHS = 70
PATIENCE = 12
BATCH = 128
LR = 0.003
PERMS = list(itertools.permutations(range(N)))
E_INDEX = {e:i for i,e in enumerate(EDGES)}
PERM_MAPPINGS = [tuple(1 << E_INDEX[(p[i],p[j])] for i,j in EDGES) for p in PERMS]


def bits(mask):
    return np.array([(mask >> k)&1 for k in range(B)], dtype=np.uint8)


def pack(x):
    return sum(int(v) << i for i,v in enumerate(x))


def pmask(mask, mapping):
    result=0
    while mask:
        lb = mask & -mask
        result |= mapping[lb.bit_length()-1]
        mask -= lb
    return result


def canon(mask):
    return min(pmask(mask, m) for m in PERM_MAPPINGS)


def sha_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):
            h.update(chunk)
    return h.hexdigest()


def write_json(path,obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')


def load_npz(path):
    with np.load(path,allow_pickle=False) as z:
        return {k:z[k] for k in z.files}


def gen_masks():
    # Deterministic isoclass disjointness, no test outcomes consulted.
    rng=np.random.default_rng(DATA_SEED)
    counts=(N_TRAIN,N_VAL,N_TEST)
    target=sum(counts)
    seen=set(); masks=[]; canonical=[]; attempts=0
    while len(masks)<target:
        if attempts>200000: raise RuntimeError('Failed to obtain enough unique isoclasses')
        p=P_GRID[attempts%len(P_GRID)]
        row=rng.binomial(1,p,size=B).astype(np.uint8)
        mask=pack(row)
        attempts+=1
        c=canon(mask)
        if c in seen: continue
        seen.add(c); masks.append(mask); canonical.append(c)
    return masks,canonical,attempts


def relabel(base, seed, aug):
    rng=np.random.default_rng(seed)
    xs=[]; cs=[]; groups=[]
    for idx,mask in enumerate(base):
        seen_mask=set()
        for r in range(aug):
            for z in range(12):
                cur=pmask(mask,PERM_MAPPINGS[int(rng.integers(len(PERMS)))])
                if cur not in seen_mask or z==11: break
            seen_mask.add(cur);xs.append(bits(cur));groups.append(idx)
    return np.stack(xs).astype(np.uint8),np.asarray(groups,dtype=np.int32)


def prepare(out):
    p=Path(out); p.mkdir(parents=True,exist_ok=True)
    masks,canonicals,attempts=gen_masks()
    segments=[('train',masks[:N_TRAIN],canonicals[:N_TRAIN],AUG_TRAIN,350211),
              ('val',masks[N_TRAIN:N_TRAIN+N_VAL],canonicals[N_TRAIN:N_TRAIN+N_VAL],AUG_VAL,350212),
              ('test_sealed',masks[N_TRAIN+N_VAL:],canonicals[N_TRAIN+N_VAL:],AUG_TEST,350213)]
    result={"attempts":attempts,"classes":{},"edge_bits":B,"message_bits":W,"base_seed":DATA_SEED}
    for split,ms,cs,aug,seed in segments:
        xx,groups=relabel(ms,seed,aug)
        np.savez_compressed(p/(split+'.npz'),x=xx,group=groups,canonical=np.asarray(cs,dtype=np.int64),base_masks=np.asarray(ms,dtype=np.int64))
        result['classes'][split]={"n_classes":len(ms),"n_views":len(xx),"sha256":sha_file(p/(split+'.npz'))}
    write_json(p/'dataset_receipt.json',result)
    return result


def query_labels(xs):
    arr=np.asarray(xs,dtype=np.uint8)
    if arr.ndim==1:arr=arr[None,:]
    out={"twohop":[],"reach":[],"mutual":[],"triangle":[]}
    for x in arr:
        A=np.zeros((N,N),dtype=np.int8)
        for i,(u,v) in enumerate(EDGES):A[u,v]=int(x[i])
        two=(A.astype(np.int32)@A.astype(np.int32)>0)
        reach=A.astype(bool).copy()
        for k in range(N):reach|=reach[:,k,None] & reach[k,None,:]
        out['twohop'].extend(int(two[i,j]) for i,j in EDGES)
        out['reach'].extend(int(reach[i,j]) for i,j in EDGES)
        out['mutual'].extend(int(reach[i,j] and reach[j,i]) for i,j in EDGES)
        tri=any(A[i,j] and A[j,k] and A[k,i] for i,j,k in itertools.permutations(range(N),3))
        out['triangle'].append(int(tri))
    return {k:np.asarray(v,dtype=np.uint8) for k,v in out.items()}


def ba(y,p):
    y=np.asarray(y).ravel();p=np.asarray(p).ravel()
    has0=np.any(y==0);has1=np.any(y==1)
    if not (has0 and has1):return float('nan')
    return float((np.mean(p[y==0]==0)+np.mean(p[y==1]==1))/2)


class Learned(nn.Module):
    def __init__(self):
        super().__init__()
        self.enc=nn.Sequential(nn.Linear(B,64),nn.ReLU(),nn.Linear(64,W))
        self.dec=nn.Sequential(nn.Linear(W,64),nn.ReLU(),nn.Linear(64,B))
    def encode(self,x):
        soft=torch.sigmoid(self.enc(x))
        hard=(soft>=0.5).float()
        return soft+(hard-soft).detach() if self.training else hard
    def forward(self,x):return self.dec(self.encode(x))


class Fixed(nn.Module):
    def __init__(self,kind,mat=None):
        super().__init__()
        self.kind=kind
        if mat is not None:self.register_buffer('fixed',torch.tensor(mat,dtype=torch.float32))
        self.dec=nn.Sequential(nn.Linear(W,64),nn.ReLU(),nn.Linear(64,B))
    def encode(self,x):
        if self.kind=='direct12':return x[:,:W]
        return torch.remainder(torch.matmul(x,self.fixed.T),2.0)
    def forward(self,x):return self.dec(self.encode(x))


def make_model(kind,seed):
    torch.manual_seed(seed)
    if kind=='learned12':return Learned()
    if kind=='direct12':return Fixed('direct12')
    if kind=='parity12':
        rng=np.random.default_rng(500000+seed)
        mat=np.zeros((W,B),dtype=np.uint8)
        for i in range(W):
            sel=rng.choice(B,size=3,replace=False)
            mat[i,sel]=1
        return Fixed('parity12',mat)
    raise ValueError(kind)


def train_one(kind,seed,train_x,val_x,out):
    model=make_model(kind,seed)
    optim=torch.optim.Adam(model.parameters(),lr=LR)
    tx=torch.from_numpy(train_x.astype(np.float32));vx=torch.from_numpy(val_x.astype(np.float32))
    rng=np.random.default_rng(70000+seed)
    best=float('inf'); best_epoch=-1; stale=0; best_state=None
    history=[]
    for epoch in range(1,EPOCHS+1):
        model.train()
        order=rng.permutation(len(tx))
        for start in range(0,len(order),BATCH):
            inds=order[start:start+BATCH]; x=tx[inds]
            optim.zero_grad(set_to_none=True)
            logits=model(x)
            loss=F.binary_cross_entropy_with_logits(logits,x)
            loss.backward();optim.step()
        model.eval()
        with torch.no_grad():
            val_loss=F.binary_cross_entropy_with_logits(model(vx),vx).item()
        history.append(round(val_loss,9))
        if val_loss<best-1e-6:
            best=val_loss;best_epoch=epoch;stale=0
            best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
        else:
            stale+=1
            if stale>=PATIENCE:break
    torch.save(best_state,out)
    return {"kind":kind,"seed":seed,"best_epoch":best_epoch,"best_val_bce":best,"epochs_run":len(history),"val_bce_series":history,"checkpoint_sha256":sha_file(out)}


def train(root):
    root=Path(root)
    assert (root/'train.npz').is_file() and (root/'val.npz').is_file()
    train_x=load_npz(root/'train.npz')['x'];val_x=load_npz(root/'val.npz')['x']
    artifacts=root/'checkpoints';artifacts.mkdir(exist_ok=True)
    rec=[]
    for kind in ('learned12','direct12','parity12'):
        for seed in EXP_SEEDS:
            fname=f'{kind}_s{seed}.pt';p=artifacts/fname
            res=train_one(kind,seed,train_x,val_x,p)
            rec.append(res)
    write_json(root/'train_receipt.json',{"training_inputs":[[n,sha_file(root/n)] for n in ('train.npz','val.npz')],"runs":rec,"torch":torch.__version__,"numpy":np.__version__})
    return rec


def infer(kind,seed,state,xx):
    model=make_model(kind,seed)
    model.load_state_dict(torch.load(state,map_location='cpu',weights_only=True))
    model.eval()
    X=torch.tensor(xx.astype(np.float32))
    with torch.no_grad():
        encoded=model.encode(X).numpy().astype(np.uint8)
        pred=(torch.sigmoid(model(X)).numpy()>=0.5).astype(np.uint8)
    return encoded,pred


def metrics(y,p):
    ya=query_labels(y);pa=query_labels(p)
    score={k:ba(ya[k],pa[k]) for k in ('twohop','reach','mutual','triangle')}
    score['macro']=float(np.mean(list(score.values())))
    score['edge_reconstruction_accuracy']=float(np.mean(y==p))
    return score


def adversarial_pairs():
    # Deliberate long-chain/cut graph pairs in same edge-label format; no independent sampling.
    full=sum(1<<E_INDEX[(i,i+1)] for i in range(N-1))
    cut=full^(1<<E_INDEX[(2,3)])
    rng=np.random.default_rng(700035)
    result=[]
    for i in range(50):
        m=PERM_MAPPINGS[int(rng.integers(len(PERMS)))];p=PERMS[PERM_MAPPINGS.index(m)]
        result.append((bits(pmask(full,m)),bits(pmask(cut,m)),p[0],p[4]))
    return result


def evaluate(root):
    root=Path(root)
    assert (root/'train_receipt.json').is_file()
    z=load_npz(root/'test_sealed.npz')
    xx=z['x']
    per=[]; codes_by_kind={}
    for kind in ('learned12','direct12','parity12'):
        for seed in EXP_SEEDS:
            path=root/'checkpoints'/f'{kind}_s{seed}.pt'
            code,pred=infer(kind,seed,path,xx)
            s=metrics(xx,pred)
            rs=np.random.default_rng(883000+seed).permutation(len(code))
            model=make_model(kind,seed);model.load_state_dict(torch.load(path,map_location='cpu',weights_only=True));model.eval()
            with torch.no_grad():
                recon=(torch.sigmoid(model.dec(torch.tensor(code[rs],dtype=torch.float32))).numpy()>=0.5).astype(np.uint8)
            shuff=metrics(xx,recon)['macro']
            pairs=adversarial_pairs();pa=np.stack([e[0] for e in pairs]);pb=np.stack([e[1] for e in pairs])
            c1,y1=infer(kind,seed,path,pa);c2,y2=infer(kind,seed,path,pb)
            wins=0;collisions=0
            for idx,(_,_,u,v) in enumerate(pairs):
                # Whether reconstructed FULL says u reaches v, but CUT does not.
                r1=query_labels(y1[idx])['reach'][E_INDEX[(u,v)]]
                r2=query_labels(y2[idx])['reach'][E_INDEX[(u,v)]]
                wins+=int(r1==1 and r2==0)
                collisions+=int(np.array_equal(c1[idx],c2[idx]))
            res={"kind":kind,"seed":seed,"metrics":s,"shuffled_macro":shuff,
                 "encoded_unique_messages":int(len(np.unique(code,axis=0))),
                 "adversarial_pairs_correct":wins,"adversarial_pairs_total":50,"adversarial_code_collisions":collisions}
            per.append(res); codes_by_kind[(kind,seed)]=code
    summary={}
    for kind in ('learned12','direct12','parity12'):
        rows=[x for x in per if x['kind']==kind]
        summary[kind]={k:float(np.mean([row['metrics'][k] for row in rows])) for k in ('twohop','reach','mutual','triangle','macro','edge_reconstruction_accuracy')}
        summary[kind]['seed_macros']=[r['metrics']['macro'] for r in rows]
        summary[kind]['mean_shuffled_macro']=float(np.mean([r['shuffled_macro'] for r in rows]))
        summary[kind]['mean_adversarial_pair_accuracy']=float(np.mean([r['adversarial_pairs_correct']/50 for r in rows]))
    learnt=summary['learned12']['macro'];base=max(summary['direct12']['macro'],summary['parity12']['macro'])
    observed_gate=(learnt >= base+0.03 and learnt>=0.6 and summary['learned12']['mean_shuffled_macro']<=learnt-0.1)
    result={"study":"MNL-PLAY-035","stage":"external toy graph model, zero new-task training", "protocol":"PREDECLARED exploratory first run",
            "source_data_hashes":{n:sha_file(root/n) for n in ('train.npz','val.npz','test_sealed.npz')},
            "per_run":per,"summary":summary,"transfer_signal_predeclared_threshold_met":observed_gate,
            "research_novelty":"NOT_ESTABLISHED_BY_DESIGN","lean_rerun":False,"frozen_history_mutations":False}
    write_json(root/'eval_result.json',result)
    return result


def audit(root):
    root=Path(root);r=json.loads((root/'eval_result.json').read_text())
    data=load_npz(root/'test_sealed.npz');x=data['x'];ori=[]
    for mask in data['base_masks'][:min(len(data['base_masks']),300)]:
        ori.append(canon(int(mask)))
    uniq=len(set(ori))==len(ori)
    allcan=[]
    for label in ('train','val','test_sealed'):
        z=load_npz(root/(label+'.npz'))
        cs={int(v) for v in z['canonical']}
        allcan.append(cs)
    disjoint=not any(allcan[i]&allcan[j] for i,j in itertools.combinations(range(3),2))
    direct_labels=query_labels(x)
    # Independent BFS check of reachability, avoiding the closure computation above.
    mismatch={k:0 for k in ('twohop','reach','mutual','triangle')}
    for i,row in enumerate(x):
        nbr={src:{dst for dst in range(N) if src!=dst and int(row[E_INDEX[(src,dst)]])} for src in range(N)}
        reach={}
        for src in range(N):
            q=deque([src]);visited={src}
            while q:
                u=q.popleft()
                for v in nbr[u]:
                    if v not in visited:visited.add(v);q.append(v)
            reach[src]=visited
        for src,dst in EDGES:
            j=i*len(EDGES)+E_INDEX[(src,dst)]
            recomputed={
                'twohop':int(any(dst in nbr[k] for k in nbr[src])),
                'reach':int(dst in reach[src]),
                'mutual':int(dst in reach[src] and src in reach[dst])
            }
            for name,value in recomputed.items():
                if value!=int(direct_labels[name][j]):mismatch[name]+=1
        tri=int(any(i1 in nbr[i3] for i1 in range(N) for i2 in nbr[i1] for i3 in nbr[i2] if len({i1,i2,i3})==3))
        if tri!=int(direct_labels['triangle'][i]):mismatch['triangle']+=1
    checks={"all_source_classes_unique":uniq,"isoclass_splits_disjoint":disjoint,"independent_task_label_mismatches":mismatch,
            "no_new_task_training":True,"latent_width_bits":W,"all_models_bit_width_equal":True,
            "input_sha256_stable":r['source_data_hashes']=={n:sha_file(root/n) for n in ('train.npz','val.npz','test_sealed.npz')}}
    checks['structural_pass']=all([uniq,disjoint,not any(mismatch.values()),checks['input_sha256_stable']])
    write_json(root/'audit_result.json',checks)
    return checks


def selftest():
    # Local DEV fixtures; no frozen evaluation data used.
    a=bits(sum(1<<E_INDEX[(i,i+1)] for i in range(N-1)))
    q=query_labels(a)
    assert q['reach'][E_INDEX[(0,4)]]==1
    cut=a.copy();cut[E_INDEX[(2,3)]]=0
    assert query_labels(cut)['reach'][E_INDEX[(0,4)]]==0
    assert len(set(canon(pmask(pack(a),m)) for m in PERM_MAPPINGS))==1
    assert len(set(canon(pmask(pack(cut),m)) for m in PERM_MAPPINGS))==1
    assert len(query_labels(a)['twohop'])==20
    xx=np.stack([a,cut]).astype(np.float32)
    for k in ('learned12','direct12','parity12'):
        net=make_model(k,3001)
        y=net(torch.tensor(xx))
        assert y.shape==(2,20)
        code=net.encode(torch.tensor(xx))
        assert code.shape==(2,W) and torch.all((code==0)|(code==1))
        loss=F.binary_cross_entropy_with_logits(y,torch.tensor(xx))
        loss.backward()
        assert math.isfinite(float(loss.item()))
    print('DEV_SELFTEST_PASS')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['selftest','prepare','train','evaluate','audit']);ap.add_argument('--root',default='/mnt/data/MNL_PLAY_035')
    args=ap.parse_args()
    if args.command=='selftest':selftest()
    if args.command=='prepare': print(json.dumps(prepare(args.root),ensure_ascii=False))
    if args.command=='train': print(json.dumps(train(args.root),ensure_ascii=False)[:4000])
    if args.command=='evaluate': print(json.dumps(evaluate(args.root)['summary'],ensure_ascii=False))
    if args.command=='audit': print(json.dumps(audit(args.root),ensure_ascii=False))
if __name__=='__main__': main()
