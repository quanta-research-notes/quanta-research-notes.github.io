#!/usr/bin/env python3
"""Re-run fixed 020/035 experiments in private temp copies; do not rewrite frozen artifacts."""
from pathlib import Path
from zipfile import ZipFile
import subprocess,tempfile,sys,json,hashlib,math,shutil
ROOT=Path(__file__).resolve().parent

def run(args,cwd,timeout=180):
    p=subprocess.run([sys.executable,*args],cwd=cwd,capture_output=True,text=True,timeout=timeout,check=True)
    return {'command':args,'last_output':p.stdout[-400:],'exit_code':p.returncode}

def main():
    records=[]
    with tempfile.TemporaryDirectory(prefix='mnl-repro-') as tmp:
        out=Path(tmp)
        with ZipFile(ROOT/'originals'/'MNL_PLAY_020_PreRun_Frozen_v0_1.zip') as z:z.extractall(out/'p020')
        p020=out/'p020'/'MNL_PLAY_020_v0_1'
        for f in ['select020.py','run020.py','audit020.py']:
            records.append(run([f],cwd=p020))
        for f in ['SELECTED_BEFORE_TEST.json','RESULTS.json','RUN_SUMMARY.json','INDEPENDENT_AUDIT.json']:
            if (p020/f).read_bytes()!=(ROOT/'mnl020'/f).read_bytes():raise AssertionError('020 replay mismatch '+f)
        aud020=json.loads((p020/'INDEPENDENT_AUDIT.json').read_text())
        if aud020.get('issue_count')!=0 or aud020.get('error_counts')!={'certified':0,'empirical':80}:
            raise AssertionError('020 audit semantics mismatch')
        p035=out/'p035';p035.mkdir()
        with ZipFile(ROOT/'originals'/'MNL035_PRERUN_FROZEN_v0_1.zip') as z:z.extractall(p035)
        with ZipFile(ROOT/'originals'/'MNL035_CHECKPOINTS_BEFORE_TEST_v0_1.zip') as z:z.extractall(p035)
        for f in ['mnl035_independent_numpy_audit_v0_1.py','MNL035_PRETRAINING_FREEZE_RECEIPT_v0_1.json','MNL035_CHECKPOINT_FREEZE_RECEIPT_v0_1.json']:
            shutil.copy2(ROOT/'mnl035'/f,p035/f)
        for f in ['MNL035_PRERUN_FROZEN_v0_1.zip','MNL035_CHECKPOINTS_BEFORE_TEST_v0_1.zip']:
            shutil.copy2(ROOT/'originals'/f,p035/f)
        # Source evaluator is the original source inside p035, not a modified wrapper.
        records.append(run(['mnl035_zeroprobe.py','evaluate','--root',str(p035)],cwd=p035))
        records.append(run(['mnl035_zeroprobe.py','audit','--root',str(p035)],cwd=p035))
        records.append(run(['mnl035_independent_numpy_audit_v0_1.py',str(p035)],cwd=p035))
        for f in ['eval_result.json','audit_result.json','MNL035_INDEPENDENT_AUDIT_RESULT_v0_1.json']:
            if (p035/f).read_bytes()!=(ROOT/'mnl035'/f).read_bytes():raise AssertionError('035 replay mismatch '+f)
        q=json.loads((p035/'eval_result.json').read_text())
        a=json.loads((p035/'MNL035_INDEPENDENT_AUDIT_RESULT_v0_1.json').read_text())
        if not q['transfer_signal_predeclared_threshold_met'] or not a['audit_pass']:raise AssertionError('035 gate/audit mismatch')
        expect={'learned12':0.7006477127573865,'direct12':0.6629362065858695,'parity12':0.5009908638038277}
        for k,v in expect.items():
            if not math.isclose(q['summary'][k]['macro'],v,abs_tol=1e-12):raise AssertionError('035 score mismatch '+k)
    print(json.dumps({'status':'REPLAY_PASS','020':'selection/test/independent audit byte-identical','035':'evaluator/structural audit/independent NumPy+NetworkX audit byte-identical','035_macros':expect,'originals_mutated':False,'commands':len(records)}))
if __name__=='__main__':main()
