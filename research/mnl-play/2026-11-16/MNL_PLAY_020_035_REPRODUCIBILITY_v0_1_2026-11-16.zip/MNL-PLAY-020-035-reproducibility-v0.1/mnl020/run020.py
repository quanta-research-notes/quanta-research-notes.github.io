"""Test runner. Reads frozen test INPUTS but NEVER gold/labels.
Records output of both pre-selected policies before independent audit.
"""
from pathlib import Path
import json,collections
from dsl020 import eval_bit,finite_graph_reach_certificate
BASE=Path(__file__).resolve().parent

def load(n):return json.loads((BASE/n).read_text())
def dump(n,x):(BASE/n).write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n')
def run():
    select=load('SELECTED_BEFORE_TEST.json'); test=load('TEST_INPUTS.json')
    assert len(test)==960 and select['test_labels_read'] is False
    empirical=[select['by_head'][str(i)]['empirical']['ast'] for i in range(5)]
    certified=[select['by_head'][str(i)]['certified']['ast'] for i in range(5)]
    assert finite_graph_reach_certificate(certified[2])
    out=[]
    for i,w in enumerate(test):
        a=[eval_bit(p,w) for p in empirical]
        b=[eval_bit(p,w) for p in certified]
        out.append({'index':i,'n':w['n'],'type':w['type'],'empirical':a,'certified':b})
    dump('RESULTS.json',out)
    count=collections.Counter(x['type'] for x in out)
    summary={'study':'MNL-PLAY-020','version':'v0.1','n_test':len(out),'test_labels_read':False,'proof_aware_expression':certified[2],'empirical_expression':empirical[2],'by_family':dict(sorted(count.items()))}
    dump('RUN_SUMMARY.json',summary)
    print(json.dumps(summary,sort_keys=True))
if __name__=='__main__':run()
