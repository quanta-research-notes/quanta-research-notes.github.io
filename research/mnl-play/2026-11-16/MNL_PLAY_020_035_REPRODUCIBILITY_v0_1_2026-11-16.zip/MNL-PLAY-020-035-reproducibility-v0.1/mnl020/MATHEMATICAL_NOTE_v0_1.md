# MNL-PLAY-020 — Mathematical note, proofs and limitations

**2026-11-02 JST.** The claims below are finite synthetic graph results or elementary, explicitly scoped mathematical theorems, **not an IUT theorem or a proof of AI-instance identity.** The 143-program DSL and the proof-recognition schema were supplied by Q; they were not invented by a neural learner.

## 1. World, question, and channel

A world is a finite directed loop-free graph with vertex set \(V=\{0,\ldots,n-1\}\), adjacency relation \(A\subseteq V^2\), and a nonempty sequence of distinct inserted directed edges \(e_0,e_1,\ldots\). The question is about source \(s=0\) and target \(t=n-1\). Let \(F\) be the singleton relation containing only the first event \(e_0\), \(U=V^2\) the universal relation, and \(\circ\) relational composition.

The five task labels are

\[
P(w)=(\mathbf 1_{A(s,t)},\ \mathbf 1_{(A\circ A)(s,t)},\ \mathbf 1_{A^+(s,t)},\ \mathbf 1_{\operatorname{src}(e_0)=s},\ \mathbf 1_{\operatorname{tgt}(e_0)=t}).
\]

Unlike 019, none of those five labels is directly supplied as an atomic feature to the candidate grammar. All selected programs consume the base relations \(A,F,I,U,Z\) and relational operations. The completed program still constructs the same five answer bits, rather than discovering an extra, general-purpose latent language.

## 2. Selected sufficient program and derived guarantees

The empirical and proof-aware selectors both chose these four expressions for positions 0,1,3,4:

- `CELL(A)` (direct edge).
- `CELL(A∘A)` (exactly two edges).
- `CELL(F∘U)` (the first event starts at s: iff some y has F(s,y)).
- `CELL(U∘F)` (the first event ends at t: iff some x has F(x,t)).

For the reachability bit, the proof-aware selector chose the **program**

\[
R_0=A,\quad R_{i+1}=R_i\cup(A\circ R_i),\quad\text{until }R_{i+1}=R_i.
\]

This program was constructed using the generic iteration grammar; it was not an atomic `RSTAR` primitive. Proof of its exactness:

**Soundness.** By induction, every pair in \(R_i\) is connected by a positive-length original-graph walk: base \(R_0=A\); each new pair in \(A\circ R_i\) adds one original edge to a previously witnessed walk. Thus \(R_i\subseteq A^+\) for all \(i\).

**Completeness at fixed point.** At the fixed point \(R\), we have \(A\subseteq R\) and \(A\circ R\subseteq R\). Induction on positive walk length gives \(A^+\subseteq R\). Therefore \(R=A^+\).

**Termination.** \(R_i\) is a monotonically increasing subset of the finite \(V^2\). More strongly, every reachable pair has a positive walk of length at most \(n\): for distinct endpoints a simple path has length at most \(n-1\), and a shortest nonempty closed walk is a simple cycle of length at most \(n\). Therefore after at most \(n\) edge-length stages the fixed point has been reached. The programmed `n+2` round safety limit is sufficient in this stated graph domain.

This is a *known standard finite-graph closure argument*. The human-provided syntactic proof gate only recognizes some sound fixed-point programs. It is **not a general automated proof search**; failure to obtain this annotation is not a proof that another candidate is wrong.

## 3. Why empirical minimal-cost selection fails

Given only the exhaustive n=4 training and n=6 validation worlds, a bounded iteration program from \(R_0=A\) and **four iterations** of \(R\leftarrow R\cup(A\circ R)\) agrees with the target on all observed graph sizes: it includes walks of lengths 1 through 5, sufficient for all distinct-vertex reachable pairs with at most six vertices.

On an n=8 chain from 0 to 7, the shortest path has length 7; on an n=10 chain, length 9. Thus the bounded program yields a false negative. Its 80 test errors are precisely 40 connected chain cases at each n; it correctly rejects cut-chain cases. `960/960` proof-aware vs `880/960` empirical is an observed outcome under this constructed benchmark, **not a representative generalization rate for AI or generic program synthesis**.

## 4. Formal capacity impossibility (D's remark, carefully scoped)

For any finite world set \(W\), question family \(P:W\to\{0,1\}^5\), and encoding \(q:W\to M\), there is a deterministic decoder \(f:M\to\{0,1\}^5\) with \(P=f\circ q\) iff every fibre of \(q\) is homogeneous in \(P\):

\[
q(w_1)=q(w_2)\ \Longrightarrow\ P(w_1)=P(w_2).
\]

On the exhaustive 24,576 n=4 training histories, there are 17 different five-label vectors. Hence no encoding with at most 16 messages (four bits) can satisfy all tasks. By the pigeonhole principle two worlds must share a message despite different labels, regardless of the learner's sophistication. The independently validated constructive witness is provided in `NO_GO_WITNESSES.json` (train indices 0 and 565 for the four-bit code made from bits 0,1,3,4).

The five-bit selected channel is sufficient **for these five questions**. It is not sufficient for arbitrary histories: training worlds at indices 0 and 1 have the same five answer bits but disagree on the previously unasked question, 'was the first event exactly 0→1?' This supplies another explicit same-code/opposite-truth witness. These are formal proofs of **interface-relative impossibility**, not claims that history is absolutely unformalizable.

## 5. Insufficiency of a restricted local observation interface

Define \(q_k(G)\) to record only \(n\), the vertices within directed distance \(\le k\) from s and edges induced on them, and vertices from which t is reachable within \(\le k\) reversed edges and edges induced on those. This interface does **not** expose the full adjacency matrix or frontier-crossing edges.

- At \(n=8,k=2\): compare the full path `0→1→2→3→4→5→6→7` with the same path minus `3→4`.
- At \(n=10,k=3\): compare the full path `0→1→…→9` with the same path minus `4→5`.

In both pairs, the two allowed endpoint neighborhoods and their induced edges are identical, so \(q_k(G_+)=q_k(G_-)\), but `REACH(s,t)` differs. Therefore no decoder of **this interface alone** can be universally correct for these cases. This does not prove that every bounded-round algorithm over full graph inputs must fail; such a stronger claim would require a separately defined computational model and proof.

## 6. Chronology and structural transport

Across 80 held-out pairs with identical final graph and different earliest event, the first three graph predicates are invariant, but the first-event source flag differs. The composed `F∘U` measurement preserves that distinction. Thus common *final function* does not imply common *event history*. Conversely the five-bit code omits finer chronological facts, as proved by the sixth-question collision.

For edge inclusion \(E_-\subset E_+\), positive reachability in \(G_-\) implies positive reachability in \(G_+\), but non-reachability in \(G_-\) does not imply non-reachability in \(G_+\). The independently tested connected/cut pair is a counterexample to the invalid reverse transfer.

## 7. Epistemic boundary

The tested search is deterministic symbolic synthesis from a **researcher-designed grammar** and explicit supervised target outputs. A separate audit used its own set-theoretic interpreter and deque BFS, not the DSL module, plus 200 interior-vertex permutations; 0 audit issues. Clean-room replay of the pre-run archive within the same runtime reproduced 11/11 canonical files byte-for-byte. This does not establish an external independent replication.

The present mathematical sufficiency is relative to stipulated synthetic event/graph inputs. It does not attest that a received log is authentic, prove an AI instance's personal identity, establish a genuinely emergent machine-native representation, or import any disputed IUT inference. IUT is a methodological prompt for admissible comparisons across nonidentified structures, not a theorem used in this study.
