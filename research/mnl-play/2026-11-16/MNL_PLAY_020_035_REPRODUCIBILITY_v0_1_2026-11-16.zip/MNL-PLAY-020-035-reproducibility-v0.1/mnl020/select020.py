"""MNL020 deterministic program synthesis: training/validation only.
Explicitly forbidden: opening TEST_INPUTS.json or GOLD_TEST_SEALED.json.
"""
from pathlib import Path
import json,hashlib,time
from dsl020 import grammar,eval_bit,finite_graph_reach_certificate
BASE=Path(__file__).resolve().parent

def load(n):return json.loads((BASE/n).read_text())
def dump(n,x):(BASE/n).write_text(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n')

def select():
    train=load('TRAIN.json'); tr_y=load('TRAIN_LABELS.json')
    val=load('VAL.json'); val_y=load('VAL_LABELS.json')
    assert len(train)==len(tr_y)==24576 and len(val)==len(val_y)==620
    # Pre-filter order fixed, but each passing candidate is then checked on all train & validation.
    pre_idx=list(range(0,len(train),17))[:70]+list(range(0,len(train),73))[:70]
    pre_idx=sorted(set(pre_idx))
    held_idx=list(range(0,len(val),11))[:60]
    results={}; candidates=grammar()
    for target_i in range(5):
        passed=[]
        for c in candidates:
            ast=c['ast']
            if any(eval_bit(ast,train[i])!=tr_y[i][target_i] for i in pre_idx):continue
            if any(eval_bit(ast,val[i])!=val_y[i][target_i] for i in held_idx):continue
            if any(eval_bit(ast,w)!=y[target_i] for w,y in zip(train,tr_y)):continue
            if any(eval_bit(ast,w)!=y[target_i] for w,y in zip(val,val_y)):continue
            passed.append(c)
        key=lambda c:(c['cost'],c['key'])
        if not passed:raise RuntimeError('No candidate fits target index '+str(target_i))
        emp=min(passed,key=key)
        proofs=[c for c in passed if finite_graph_reach_certificate(c['ast'])] if target_i==2 else passed
        if not proofs:raise RuntimeError('No proof-certified reach program found')
        certified=min(proofs,key=key)
        results[str(target_i)]={'num_exact_candidates':len(passed),'empirical':emp,'certified':certified,'certified_general_reach_proof_schema':bool(target_i==2)}
    summary={'study':'MNL-PLAY-020','version':'v0.1','grammar_candidates':len(candidates),'training_count':len(train),'validation_count':len(val),'selection':'min cost then canonical AST; certified reach must have symbolic least-fixed-point schema','by_head':results,'test_labels_read':False,'test_inputs_read':False}
    dump('SELECTED_BEFORE_TEST.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k!='by_head'},sort_keys=True))
    for i,r in results.items():print('HEAD',i,'candidates',r['num_exact_candidates'],'empirical',r['empirical'],'certified',r['certified'])
    return summary
if __name__=='__main__':select()
