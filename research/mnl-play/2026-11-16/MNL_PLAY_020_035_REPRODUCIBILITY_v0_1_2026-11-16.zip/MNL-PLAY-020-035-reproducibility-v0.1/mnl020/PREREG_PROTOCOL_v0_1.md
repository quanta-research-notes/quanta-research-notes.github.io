# MNL-PLAY-020 — pre-run contract v0.1 (2026-11-02 JST)

## Question, boundaries, epistemic honesty
Can a deterministic computational program search **compose** five task-sufficient binary features from low-level graph/event operators **without directly named target-property primitives**, and can it prove when small message width or restricted observation interfaces are insufficient? This is finite symbolic program synthesis over a hand-designed DSL; NOT training GPT weights, machine invention of a new theorem, an unbounded general-purpose mathematical language, proof of real AI identity, or verification of IUT. MNL-0 and MNL-PLAY-007–019 frozen artifacts remain byte-immutable. TADASU × Q BLIND-002 / Trial L data are excluded.

## World, tasks and fixed data split
World is a loop-free n-vertex directed graph whose distinct edges have an event ordering. Source is 0, target n-1. The five **target tasks for supervised selection only** are: existence of direct source-target edge, exact two-edge walk, source-target nonempty reachability, first event starts at source, first event ends at target. Target labels are not available as built-in DSL operators.

- TRAIN: **all 24,576** 4-vertex graph-plus-first-event worlds, 17 possible 5-bit target vectors; chronological events after first are a fixed sorted canonical order.
- VAL: **620** seeded 6-vertex worlds, including random and 40 chain/cut and 40 chronological pairs.
- TEST (locked): **960** unseen 8-/10-vertex worlds, 320 random + 40 long-chain/cut pairs + 40 same-final/different-first-event pairs **for each size**. Training and validation labels can be used in program selection; TEST_INPUTS may be opened only by the runner after selection; GOLD_TEST_SEALED only by independent auditor after results are saved. Corpus sizes are disjoint, not 960 independent model families.

## Low-level DSL — no direct task oracle
Typed Boolean relations represented by bitset row matrices. Base atoms: `A` adjacency, `F` one-hot **earliest event** (generic event observation; it is not an F_SRC/F_TGT answer bit), `I` identity, `U` universal relation, `Z` empty. Builders: transpose, relation composition (Boolean matrix multiplication), relation union, generated bounded powers/walk unions, and generic finite iterative update `R <- R OR/AND (R ∘ B)` or `R <- R OR/AND (B ∘ R)`, with either fixed iteration count or stop on equality. All candidates read only final relation at cell (0,n-1); no labels appear in expression grammar. Grammar generation and costs fixed in dsl020.py and hashed pre-run; no selection based on held-out results.

## Two selection policies (both preregistered)
For each of 5 target bits, keep candidates that exactly match every TRAIN and VAL label. Rank by predeclared grammar `cost`, then canonical serialized AST. **Empirical policy** chooses first. **Proof-aware policy** restricts target bit #2 (reachability) to an explicitly human-provided, syntactic *sufficient proof schema*: monotonically iterate `R <- R ∪ (R∘A)` or `R <- R ∪ (A∘R)` from seed A or I until stable, then use its cell value; for all other target bits, select like empirical policy. The generic reachability proof is known mathematics (base, strict path derivation, closure) and is *not* machine discovered. At most n+2 rounds for finite n. Any failure/crash freezes v0.1 as failure rather than silently fixing.

## Primary evaluation and counterexamples
Primary thresholds: all 960 test labels independently recomputed; proof-aware program must answer **960/960** correctly with 0 unsupported judgments, selected 5-bit channel has exact 17 observed labels at n=4, train/val fitted exactly, independent audit errors=0. We will report empirical policy's errors (not suppress if negative), by-size and chain/cut breakdown, and full grammar selection including what the candidate language supplied.

Required constructive impossibilities:
1. Four bits cannot encode all 17 distinct five-target vectors (pigeonhole); supply a concrete same-four-bit/different-five-vector pair.
2. For `q_k` recording only induced directed neighborhoods of radius k from source and reverse-radius k from target (plus n), provide chain/cut pair of n=8,k=2 and n=10,k=3 with *identical q_k* but opposing source-target reachability. This shows a limitation of that explicit observation interface, **not of all fixed-depth algorithms with access to the whole graph**.
3. Find two distinct chronology histories with *identical five target bits* but opposite sixth, unasked historical predicate: earliest edge is exactly 0→1. Even task-perfect 5-bit channel cannot answer this extra query on both histories.
4. Verify interior relabeling invariance for 200 fixed held-out graphs. Verify 80 same-final-state/different-first-event matched pairs. For an unsafe invalid structure-bridge (graph with removed middle edge) do not infer reverse transfer of reachability.

Independent auditor must NOT import dsl020, select020, run020 or prepare020. It independently interprets candidate AST, recomputes BFS and historical predicate labels, validates all stated witnesses, verifies provenance SHA and test-read boundary, and issues explicit failures. Preserve primary vs exploratory tests separately. Signed real-world authority is NOT inferred from synthetic input hashes. Never conflate expression synthesis with AI-invented primitive mathematical language.
