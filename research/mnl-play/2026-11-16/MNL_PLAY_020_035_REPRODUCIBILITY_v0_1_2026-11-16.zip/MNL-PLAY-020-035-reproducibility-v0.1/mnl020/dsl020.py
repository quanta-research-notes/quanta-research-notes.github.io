"""MNL-PLAY-020 low-level relation expression DSL. No target-named primitive.
No access to sealed labels, training labels or scoring modules.
"""
import json

ATOM = ('A', 'F', 'I', 'U', 'Z')

def canonical(x):
    return json.dumps(x, ensure_ascii=True, separators=(',', ':'))

def matmul(x,y,n):
    rows=[]
    for i in range(n):
        bits=x[i]; z=0
        while bits:
            step=bits & -bits; j=step.bit_length()-1
            z |= y[j]; bits ^= step
        rows.append(z)
    return tuple(rows)

def mattranspose(x,n):
    out=[0]*n
    for i,row in enumerate(x):
        for j in range(n):
            if row>>j&1:out[j]|=1<<i
    return tuple(out)

def world_matrices(w):
    n=w['n']; a=[0]*n
    for e in w['events']:
        u,v=divmod(e,n);a[u]|=1<<v
    f=[0]*n
    u,v=divmod(w['events'][0],n);f[u]|=1<<v
    alln=(1<<n)-1
    return {'A':tuple(a),'F':tuple(f),'I':tuple(1<<i for i in range(n)), 'U':(alln,)*n, 'Z':(0,)*n}

def eval_matrix(node, m, n):
    op=node[0]
    if op=='ATOM':return m[node[1]]
    if op=='TR':return mattranspose(eval_matrix(node[1],m,n),n)
    if op=='COMP':return matmul(eval_matrix(node[1],m,n),eval_matrix(node[2],m,n),n)
    if op=='OR':
        a=eval_matrix(node[1],m,n);b=eval_matrix(node[2],m,n)
        return tuple(x|y for x,y in zip(a,b))
    if op=='WALK':
        # Generated syntax, not a built-in reachability oracle: OR(A,A*A,... A^k).
        k=node[1]; val=m['A'];out=val
        for _ in range(2,k+1):
            val=matmul(val,m['A'],n)
            out=tuple(a|b for a,b in zip(out,val))
        return out
    if op=='LOOP':
        _,seed,driver,side,merge,mode,rounds=node
        cur=m[seed]; base=m[driver]
        # generic relation iteration: R <- R op (R ∘ Base) or its reverse.
        limit = n+2 if mode=='STABLE' else rounds
        for _ in range(limit):
            step=matmul(cur,base,n) if side=='R' else matmul(base,cur,n)
            if merge=='OR': nxt=tuple(a|b for a,b in zip(cur,step))
            elif merge=='AND': nxt=tuple(a&b for a,b in zip(cur,step))
            else: raise ValueError('unknown merge')
            if nxt==cur:
                if mode=='STABLE':return cur
                # When fixed count, mathematically idempotent from here.
                return cur
            cur=nxt
        if mode=='STABLE':
            raise AssertionError('iteration failed to converge')
        return cur
    raise ValueError(op)

def eval_bit(node,w):
    n=w['n']; m=world_matrices(w); return int(bool(eval_matrix(node,m,n)[0] & (1<<(n-1))))

def grammar():
    """Finite generator of ASTs from raw relations and algebraic constructors.
    Expressions never contain target-task named features.
    """
    nodes=[]
    for a in ATOM: nodes.append((('ATOM',a),1))
    for a in ('A','F'):
        nodes.append((('TR',('ATOM',a)),2))
    for a in ATOM:
        for b in ATOM:
            nodes.append((('COMP',('ATOM',a),('ATOM',b)),3))
            if a<b:nodes.append((('OR',('ATOM',a),('ATOM',b)),3))
    for k in range(2,7):nodes.append((('WALK',k),2+k))
    for seed in ('A','I','F'):
        for driver in ('A','F'):
            for side in ('L','R'):
                for merge in ('OR','AND'):
                    for mode,rounds in [('COUNT',3),('COUNT',4),('COUNT',5),('STABLE',0)]:
                        cost=12 if mode=='STABLE' else 2+rounds
                        nodes.append((('LOOP',seed,driver,side,merge,mode,rounds),cost))
    uniq={canonical(ast):(ast,cost) for ast,cost in nodes}
    return [{'ast':a,'cost':c,'key':canonical(a)} for a,c in sorted(uniq.values(),key=lambda x:canonical(x[0]))]

def finite_graph_reach_certificate(ast):
    """Predeclared symbolic sufficient pattern for all finite graphs.
    Explicit human-provided proof schema, not a discovered theorem.
    """
    if ast[0]!='LOOP':return False
    _,seed,driver,side,merge,mode,rounds=ast
    return (seed in ('A','I') and driver=='A' and merge=='OR' and mode=='STABLE')
