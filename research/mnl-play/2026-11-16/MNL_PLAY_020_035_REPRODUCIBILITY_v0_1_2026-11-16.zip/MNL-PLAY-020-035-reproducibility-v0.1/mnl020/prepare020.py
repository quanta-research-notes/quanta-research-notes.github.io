"""Generate predetermined synthetic graph/event worlds. No model selection.
The held-out labels are written to a separate file, not read by the runner.
"""
from pathlib import Path
import json,random,collections
BASE=Path(__file__).resolve().parent

def dump(name,data):
    (BASE/name).write_text(json.dumps(data,sort_keys=True,separators=(',',':'))+'\n',encoding='utf-8')

def reaches(n,edges):
    found={0}; todo=[0]
    while todo:
        u=todo.pop()
        for e in edges:
            x,y=divmod(e,n)
            if x==u and y not in found:
                found.add(y);todo.append(y)
    return n-1 in found

def label(w):
    n=w['n']; E=set(w['events']); a=0;b=n-1
    two=any((a*n+v in E and v*n+b in E) for v in range(n))
    src,tgt=divmod(w['events'][0],n)
    return [int(a*n+b in E),int(two),int(reaches(n,E)),int(src==a),int(tgt==b)]

def possible_edges(n):return [u*n+v for u in range(n) for v in range(n) if u!=v]

def random_world(n,rng,typ):
    es=possible_edges(n)
    if typ=='sparse': p=.10
    elif typ=='medium':p=.25
    elif typ=='dense':p=.52
    elif typ=='very_sparse':p=.055
    else:raise ValueError(typ)
    edges=[e for e in es if rng.random()<p]
    if not edges:edges=[rng.choice(es)]
    rng.shuffle(edges)
    return {'n':n,'events':edges,'type':typ}

def chain_world(n,rng,cut=False):
    # Only backwards optional edges; impossible to bridge a missing forward link.
    chain=[u*n+u+1 for u in range(n-1)]
    if cut:chain.remove((n//2-1)*n+n//2)
    extra=[u*n+v for u in range(n) for v in range(u) if rng.random()<.08]
    es=chain+extra
    rng.shuffle(es)
    return {'n':n,'events':es,'type':'cut' if cut else 'chain'}

def chrono_pair(n,rng):
    es=set([n*0+1, n*1+(n-1), n*2+3, n*(n-2)+(n-1)])
    es={e for e in es if e//n != e%n}
    for e in possible_edges(n):
        if rng.random()<.15:es.add(e)
    ordered=sorted(es)
    fs=0*n+1;fn=2*n+3
    if fs not in es or fn not in es:raise AssertionError('chrono fixture')
    seq1=[fs]+[e for e in ordered if e!=fs]
    seq2=[fn]+[e for e in ordered if e!=fn]
    return ({'n':n,'events':seq1,'type':'chronological_A'}, {'n':n,'events':seq2,'type':'chronological_B'})

def make(n,seed,random_count,chain_pairs,chrono_pairs):
    rng=random.Random(seed);out=[]
    for i in range(random_count):out.append(random_world(n,rng,['sparse','medium','dense','very_sparse'][i%4]))
    for i in range(chain_pairs):
        out.append(chain_world(n,rng,False));out.append(chain_world(n,rng,True))
    for i in range(chrono_pairs):out.extend(chrono_pair(n,rng))
    return out

def main():
    # Exhaustive n4 first-occurred-edge worlds, same finite-domain basis as 019,
    # generated anew with explicitly defined chronology rules.
    n=4; ed=possible_edges(n);train=[]
    for mask in range(1,1<<len(ed)):
        chosen=[ed[i] for i in range(len(ed)) if mask>>i&1]
        for first in chosen:
            train.append({'n':n,'events':[first]+[e for e in chosen if e!=first], 'type':'exhaustive_n4'})
    assert len(train)==24576
    val=make(6,620026,460,40,40) # 620
    test=make(8,820026,320,40,40)+make(10,1020026,320,40,40) # 960
    assert len(val)==620 and len(test)==960
    for group in (train,val,test):
        for w in group:
            assert len(w['events'])==len(set(w['events'])) and len(w['events'])>0
            assert all(u!=v for u,v in (divmod(e,w['n']) for e in w['events']))
    dump('TRAIN.json',train);dump('TRAIN_LABELS.json',[label(w) for w in train]);dump('VAL.json',val);dump('VAL_LABELS.json',[label(w) for w in val]);dump('TEST_INPUTS.json',test);dump('GOLD_TEST_SEALED.json',[label(w) for w in test]);
    keys=[''.join(map(str,x)) for x in map(label,train)]
    summary={'training':len(train),'validation':len(val),'test':len(test),'train_distinct_label_vectors':len(set(keys)),'test_chronological_pairs':80,'test_chain_cut_pairs':80,'separate_sizes':{'train':[4],'val':[6],'test':[8,10]},'train_label_histogram':dict(sorted(collections.Counter(keys).items()))}
    dump('PREPARE_SUMMARY.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k!='train_label_histogram'},sort_keys=True))
if __name__=='__main__':main()
