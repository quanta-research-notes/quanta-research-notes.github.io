"""Independent MNL-PLAY-020 auditor: set-theoretic AST interpreter and deque BFS.
CRITICAL: no import of generator, model/selector, runner, or original DSL.
Uses sealed labels only AFTER frozen first-pass results exist.
"""
from pathlib import Path
import json,hashlib,random,ast as pyast,collections
from collections import deque
BASE=Path(__file__).resolve().parent

def load(n):return json.loads((BASE/n).read_text())
def dump(n,obj):(BASE/n).write_text(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n')

def set_matrix(w):
    n=w['n'];E={divmod(e,n) for e in w['events']}
    return {'A':E,'F':{divmod(w['events'][0],n)},'I':{(i,i) for i in range(n)},'U':{(i,j) for i in range(n) for j in range(n)},'Z':set()}

def scmp(left,right):
    fromright=collections.defaultdict(set)
    for a,b in right:fromright[a].add(b)
    return {(u,w) for (u,v) in left for w in fromright[v]}

def independent_eval(node,base,n):
    kind=node[0]
    if kind=='ATOM':
        assert node[1] in ('A','F','I','U','Z')
        return base[node[1]]
    if kind=='TR':return {(v,u) for u,v in independent_eval(node[1],base,n)}
    if kind=='COMP':return scmp(independent_eval(node[1],base,n),independent_eval(node[2],base,n))
    if kind=='OR':return independent_eval(node[1],base,n)|independent_eval(node[2],base,n)
    if kind=='WALK':
        assert node[1] in range(2,7)
        p=base['A'].copy(); found=p.copy()
        for _ in range(1,node[1]):
            p=scmp(p,base['A']);found.update(p)
        return found
    if kind=='LOOP':
        _,start,drive,side,merge,mode,count=node
        assert start in ('A','I','F') and drive in ('A','F') and side in ('L','R')
        assert merge in ('OR','AND') and ((mode=='STABLE' and count==0) or (mode=='COUNT' and count in (3,4,5)))
        cur=base[start].copy();D=base[drive]
        cap=n+2 if mode=='STABLE' else count
        for _ in range(cap):
            new=scmp(cur,D) if side=='R' else scmp(D,cur)
            nxt=(cur|new) if merge=='OR' else (cur&new)
            if cur==nxt:return cur
            cur=nxt
        if mode=='STABLE':raise AssertionError('unproven fixed point')
        return cur
    raise AssertionError('invalid operator '+str(kind))

def independent_labels(w):
    n=w['n']; edges={divmod(e,n) for e in w['events']}
    adj=collections.defaultdict(set)
    for a,b in edges:adj[a].add(b)
    # BFS: algorithmically distinct from generator's work-list and DSL closure.
    discovered={0}; Q=deque([0])
    while Q:
        u=Q.popleft()
        for v in adj[u]:
            if v not in discovered:
                discovered.add(v);Q.append(v)
    start,end=divmod(w['events'][0],n)
    return [int((0,n-1) in edges),int(any((0,x) in edges and (x,n-1) in edges for x in range(n))),int(n-1 in discovered),int(start==0),int(end==n-1)]

def sign4(l):return (l[0],l[1],l[3],l[4])
def first_01(w):return int(w['events'][0]==1)

def bounded_observation(w,k):
    n=w['n'];E={divmod(x,n) for x in w['events']}
    nextmap=collections.defaultdict(set);prevmap=collections.defaultdict(set)
    for a,b in E: nextmap[a].add(b);prevmap[b].add(a)
    def ball(root,neighbors):
        s={root};fr={root}
        for _ in range(k):
            nxt=set()
            for u in fr:nxt.update(neighbors[u])
            fr=nxt-s;s|=fr
        return sorted(s),sorted((a,b) for a,b in E if a in s and b in s)
    return {'n':n,'source_view':ball(0,nextmap),'target_view':ball(n-1,prevmap)}

def bridge_counterexample(n):
    all_edges=[u*n+u+1 for u in range(n-1)]
    broken=[e for e in all_edges if e!=(n//2-1)*n+n//2]
    w1={'n':n,'events':all_edges};w2={'n':n,'events':broken}
    return w1,w2

def main():
    allowed_reads={'select020.py':{'TRAIN.json','TRAIN_LABELS.json','VAL.json','VAL_LABELS.json'},'run020.py':{'SELECTED_BEFORE_TEST.json','TEST_INPUTS.json'}}
    issues=[]
    # Inspect all literal load() call targets without importing model code.
    for fname,allowed in allowed_reads.items():
        root=pyast.parse((BASE/fname).read_text())
        calls={x.args[0].value for x in pyast.walk(root) if isinstance(x,pyast.Call) and isinstance(x.func,pyast.Name) and x.func.id=='load' and x.args and isinstance(x.args[0],pyast.Constant) and isinstance(x.args[0].value,str)}
        if calls-allowed:issues.append('model_accesses_forbidden_file_'+fname+str(calls-allowed))
    freeze=load('FREEZE_v0_1.json')
    hashfail=[]
    for name,meta in freeze['members'].items():
        p=BASE/name;b=p.read_bytes()
        if hashlib.sha256(b).hexdigest()!=meta['sha256'] or len(b)!=meta['size_bytes']:hashfail.append(name)
    if hashfail:issues.append('frozen_member_mismatch_'+repr(hashfail))
    selection=load('SELECTED_BEFORE_TEST.json'); rows=load('RESULTS.json'); gold=load('GOLD_TEST_SEALED.json'); test=load('TEST_INPUTS.json')
    train=load('TRAIN.json');tl=load('TRAIN_LABELS.json');val=load('VAL.json');vl=load('VAL_LABELS.json')
    if len(rows)!=960 or len(test)!=960 or len(gold)!=960:issues.append('unexpected_test_count')
    chosen={policy:[selection['by_head'][str(j)][policy]['ast'] for j in range(5)] for policy in ('empirical','certified')}
    proof=chosen['certified'][2]
    if not (proof[0]=='LOOP' and proof[1] in ('A','I') and proof[2]=='A' and proof[4]=='OR' and proof[5]=='STABLE'):
        issues.append('no_universal_closure_lemma_for_certified_program')
    disagreements=collections.Counter(); all_truth=[]; chrono=0; chain=0
    for i,(w,y,received) in enumerate(zip(test,gold,rows)):
        truth=independent_labels(w);all_truth.append(truth)
        if y!=truth:issues.append('sealed_reference_mismatch_'+str(i))
        for name in chosen:
            output=[int((0,w['n']-1) in independent_eval(p,set_matrix(w),w['n'])) for p in chosen[name]]
            if output!=received[name]:issues.append('wrong_program_trace_'+name+'_'+str(i))
            if output!=truth:disagreements[(name,w['type'])]+=1
        if chosen['certified'] and received['certified']!=truth:issues.append('proof_aware_incorrect_'+str(i))
    for w,y in zip(train,tl):
        if independent_labels(w)!=y:issues.append('bad_training_truth');break
    for w,y in zip(val,vl):
        if independent_labels(w)!=y:issues.append('bad_validation_truth');break
    vectors={tuple(x) for x in tl}
    if len(vectors)!=17:issues.append('training_label_count_not_17')
    observed={};four_witness=None;sixth_seen={};sixth_witness=None
    for idx,(w,y) in enumerate(zip(train,tl)):
        code=sign4(y)
        if four_witness is None and code in observed and observed[code][1]!=y:
            four_witness={'indices':[observed[code][0],idx],'four_bit_code':code,'labels':[observed[code][1],y]}
        elif code not in observed: observed[code]=(idx,y)
        five=tuple(y);new=first_01(w)
        if sixth_witness is None and five in sixth_seen and sixth_seen[five][1]!=new:
            sixth_witness={'indices':[sixth_seen[five][0],idx],'five_bit_code':five,'unasked_values':[sixth_seen[five][1],new]}
        elif five not in sixth_seen:sixth_seen[five]=(idx,new)
    if four_witness is None:issues.append('no_four_bit_impossibility_witness')
    if sixth_witness is None:issues.append('no_unasked_query_collision')
    obs_witness=[]
    for n,k in ((8,2),(10,3)):
        aa,bb=bridge_counterexample(n)
        if bounded_observation(aa,k)!=bounded_observation(bb,k) or independent_labels(aa)[2]==independent_labels(bb)[2]:
            issues.append('local_view_no_go_not_proved_'+str(n))
        else:
            obs_witness.append({'n':n,'radius':k,'removed_edge':(n//2-1,n//2),'same_observation':True,'opposite_reach':True})
    # Data fixture pairing positions are fixed before evaluation.
    chrono_pairs=0; cut_pairs=0
    for offset in (0,480):
        for t in range(offset+400,offset+480,2):
            a,b=test[t:t+2]
            if set(a['events'])!=set(b['events']) or a['events'][0]==b['events'][0]:issues.append('chrono_not_paired_'+str(t))
            if all_truth[t][:3]!=all_truth[t+1][:3] or all_truth[t][3:]==all_truth[t+1][3:]: issues.append('chrono_bad_truth_'+str(t))
            chrono_pairs+=1
        for t in range(offset+320,offset+400,2):
            a,b=test[t:t+2]
            if all_truth[t][2]!=1 or all_truth[t+1][2]!=0:issues.append('chain_cut_not_discriminated_'+str(t))
            cut_pairs+=1
    # Interior relabeling invariance; source and target fixed.
    rng=random.Random(20020)
    relabel_checks=0
    for w in test[:200]:
        n=w['n'];perm=list(range(n)); interior=perm[1:-1];rng.shuffle(interior);perm[1:-1]=interior
        transformed={'n':n,'events':[perm[u]*n+perm[v] for e in w['events'] for u,v in [divmod(e,n)]]}
        if independent_labels(w)!=independent_labels(transformed):issues.append('label_relabel_fail')
        for policy,programs in chosen.items():
            before=[(0,n-1) in independent_eval(program,set_matrix(w),n) for program in programs]
            after=[(0,n-1) in independent_eval(program,set_matrix(transformed),n) for program in programs]
            if before!=after:issues.append('program_relabel_fail_'+policy)
        relabel_checks+=1
    # Accepted transformation: adding edges to a graph preserves positive reachability,
    # but missing-edge nonreachability does not reflect from cut to connected superset.
    aa,bb=bridge_counterexample(8)
    if not (set(bb['events'])<set(aa['events']) and independent_labels(aa)[2]==1 and independent_labels(bb)[2]==0): issues.append('reverse_transport_counterexample_not_constructed')
    output={'study':'MNL-PLAY-020','version':'v0.1','tested':len(test),'train_reference_checked':len(train),'validation_reference_checked':len(val),'freeze_member_mismatches':hashfail,'issues':issues[:80],'issue_count':len(issues),'misjudgments_by_policy_family':{p:{t:disagreements[(p,t)] for t in sorted({x['type'] for x in test})} for p in chosen},'error_counts':{p:sum(v for (k,t),v in disagreements.items() if k==p) for p in chosen},'four_bit_witness':four_witness,'unasked_sixth_query_witness':sixth_witness,'local_radius_no_go_witnesses':obs_witness,'chronology_pairs_verified':chrono_pairs,'chain_cut_pairs_verified':cut_pairs,'interior_relabelings_checked':relabel_checks,'capacity_distinct_vectors':len(vectors),'capacity_bits_lower_bound':5,'test_labels_hidden_from_selector_runner_by_literal_read_audit':True,'same_investigator_separately_coded':True}
    dump('INDEPENDENT_AUDIT.json',output)
    print(json.dumps({k:v for k,v in output.items() if k not in ('misjudgments_by_policy_family','four_bit_witness','unasked_sixth_query_witness')},sort_keys=True))
    if issues:raise SystemExit('INDEPENDENT_AUDIT_FAIL')
if __name__=='__main__':main()
