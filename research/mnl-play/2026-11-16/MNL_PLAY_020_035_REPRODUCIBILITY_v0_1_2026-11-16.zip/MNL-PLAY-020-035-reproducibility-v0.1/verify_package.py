#!/usr/bin/env python3
"""Validate MNL research archival snapshots without executing research code."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json,stat,sys
ROOT=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def die(msg):raise SystemExit('VERIFY_FAIL '+str(msg))

def main():
    manifest=ROOT/'FILE_HASHES.sha256'
    if not manifest.exists():die('missing FILE_HASHES.sha256')
    expected={}
    for line in manifest.read_text(encoding='utf-8').splitlines():
        h,sep,p=line.partition('  ')
        if not sep or len(h)!=64 or p in expected:die('malformed or duplicate manifest')
        expected[p]=h
    actual={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in ROOT.rglob('*') if p.is_file() and p!=manifest}
    if actual!=expected:
        die({'missing':sorted(expected.keys()-actual.keys()),'unexpected':sorted(actual.keys()-expected.keys()),'mismatches':[p for p in actual.keys() & expected.keys() if actual[p]!=expected[p]]})
    prior=json.loads((ROOT/'PROVENANCE.json').read_text())['source_archives']
    for name,h in prior.items():
        p=ROOT/'originals'/name
        if sha(p.read_bytes())!=h:die('original archive mismatch '+name)
        with ZipFile(p) as z:
            for info in z.infolist():
                path=Path(info.filename)
                if info.filename.startswith('/') or '..' in path.parts or stat.S_IFMT(info.external_attr>>16)==stat.S_IFLNK:die('unsafe ZIP member')
            if z.testzip() is not None:die('CRC mismatch '+name)
    with ZipFile(ROOT/'originals'/'MNL_PLAY_020_v0_1_Executed_2026-11-02.zip') as z:
        for n in z.namelist():
            if (ROOT/'mnl020'/Path(n).name).read_bytes()!=z.read(n):die('extracted 020 mismatch '+n)
    with ZipFile(ROOT/'originals'/'MNL035_PRERUN_FROZEN_v0_1.zip') as z:
        for n in z.namelist():
            if (ROOT/'mnl035'/n).read_bytes()!=z.read(n):die('extracted 035 pre mismatch '+n)
    with ZipFile(ROOT/'originals'/'MNL035_CHECKPOINTS_BEFORE_TEST_v0_1.zip') as z:
        for n in z.namelist():
            if (ROOT/'mnl035'/n).read_bytes()!=z.read(n):die('extracted 035 checkpoint mismatch '+n)
    with ZipFile(ROOT/'originals'/'MNL035_EXECUTION_AND_INDEPENDENT_AUDIT_v0_1.zip') as z:
        for n in ['mnl035_independent_numpy_audit_v0_1.py','eval_result.json','audit_result.json','MNL035_INDEPENDENT_AUDIT_RESULT_v0_1.json','MNL035_PRETRAINING_FREEZE_RECEIPT_v0_1.json','MNL035_CHECKPOINT_FREEZE_RECEIPT_v0_1.json']:
            if (ROOT/'mnl035'/n).read_bytes()!=z.read(n):die('extracted 035 executed mismatch '+n)
    print(json.dumps({'status':'VERIFY_PASS','files_checked':len(actual),'original_archives':len(prior),'originals_byte_identical':True,'all_zip_crc_pass':True,'package_sha_manifest_pass':True}))
if __name__=='__main__':main()
